import Advertisement from "../models/user.model.js";
import { errorHandler } from '../utils/error.js';

// Create a new advertisement
export const create = async (req, res, next) => {
    try {
        const { title, content, category, image } = req.body;
        const newAdvertisement = new Advertisement({
            title,
            content,
            category,
            image,
            userId: req.user.id // Assuming you have a middleware to extract user id from request
        });
        const savedAdvertisement = await newAdvertisement.save();
        res.status(201).json(savedAdvertisement);
    } catch (error) {
        next(errorHandler(500, error.message || 'Internal Server Error'));
    }
};

// Get all advertisements by user id
export const getAdvertisements = async (req, res, next) => {
    try {
        const userId = req.query.userId;
        const advertisements = await Advertisement.find({ userId });
        res.status(200).json({ advertisements });
    } catch (error) {
        next(errorHandler(500, error.message || 'Internal Server Error'));
    }
};

// Delete an advertisement
export const deleteAdvertisement = async (req, res, next) => {
    try {
        const advertisementId = req.params.advertisementId; // Removed userId  
        await Advertisement.deleteOne({ userid: advertisementId });
        res.status(204).end();
    } catch (error)
     {
        next(errorHandler(500, error.message || 'Internal Server Error'));
    }
};

// Update an advertisement
export const updateAdvertisement = async (req, res, next) => {
    try {
        const advertisementId = req.params.advertisementId; // Removed userId
        const { title, content, category, image } = req.body;
        const updatedAdvertisement = await Advertisement.findOneAndUpdate(
            { _id: advertisementId },
            { title, content, category, image },
            { new: true }
        );
        if (!updatedAdvertisement) {
            return res.status(404).json({ message: 'Advertisement not found' });
        }
        res.status(200).json(updatedAdvertisement);
    } catch (error) {
        next(errorHandler(500, error.message || 'Internal Server Error'));
    }
};