import express from 'express';
// import { verifyToken } from '../utils/verifyUser.js';
// Correct the imported function name here from `getAdvertisement` to `getAdvertisements`
import { create, deleteAdvertisement, getAdvertisements, updateAdvertisement } from '../controllers/Advertisement.controller.js';

const router = express.Router();

router.post('/create', create);
router.get('/getAdvertisements', getAdvertisements); 
router.delete('/deleteAdvertisement/:advertisementId',  deleteAdvertisement); // Removed unnecessary :userId
router.put('/updateAdvertisement/:advertisementId',  updateAdvertisement);

export default router;
